//
// $Id: LocationReceiver.java 4602 2007-02-24 00:39:27Z mdb $
//
// Narya library - tools for developing networked games
// Copyright (C) 2002-2007 Three Rings Design, Inc., All Rights Reserved
// http://www.threerings.net/code/narya/
//
// This library is free software; you can redistribute it and/or modify it
// under the terms of the GNU Lesser General Public License as published
// by the Free Software Foundation; either version 2.1 of the License, or
// (at your option) any later version.
//
// This library is distributed in the hope that it will be useful,
// but WITHOUT ANY WARRANTY; without even the implied warranty of
// MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the GNU
// Lesser General Public License for more details.
//
// You should have received a copy of the GNU Lesser General Public
// License along with this library; if not, write to the Free Software
// Foundation, Inc., 59 Temple Place, Suite 330, Boston, MA 02111-1307 USA

package com.threerings.crowd.client;

import com.threerings.presents.client.InvocationReceiver;

/**
 * Defines, for the location services, a set of notifications delivered
 * asynchronously by the server to the client.
 */
public interface LocationReceiver extends InvocationReceiver
{
    /**
     * Used to communicate a required move notification to the client. The
     * server will have removed the client from their existing location
     * and the client is then responsible for generating a {@link
     * LocationService#moveTo} request to move to the new location.
     */
    public void forcedMove (int placeId);
}

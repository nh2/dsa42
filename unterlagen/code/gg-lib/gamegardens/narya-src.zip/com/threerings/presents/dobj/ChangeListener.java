//
// $Id: ChangeListener.java 4602 2007-02-24 00:39:27Z mdb $
//
// Narya library - tools for developing networked games
// Copyright (C) 2002-2007 Three Rings Design, Inc., All Rights Reserved
// http://www.threerings.net/code/narya/
//
// This library is free software; you can redistribute it and/or modify it
// under the terms of the GNU Lesser General Public License as published
// by the Free Software Foundation; either version 2.1 of the License, or
// (at your option) any later version.
//
// This library is distributed in the hope that it will be useful,
// but WITHOUT ANY WARRANTY; without even the implied warranty of
// MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the GNU
// Lesser General Public License for more details.
//
// You should have received a copy of the GNU Lesser General Public
// License along with this library; if not, write to the Free Software
// Foundation, Inc., 59 Temple Place, Suite 330, Boston, MA 02111-1307 USA

package com.threerings.presents.dobj;

/**
 * The various listener interfaces (e.g. {@link EventListener}, {@link
 * AttributeChangeListener}, etc.) all extend this base interface so that
 * the distributed object can check to make sure when an object is adding
 * itself as a listener of some sort that it actually implements at least
 * one of the listener interfaces. Thus, all listener interfaces must
 * extend this one.
 */
public interface ChangeListener
{
}

//
// $Id: Log.java 270 2007-04-07 00:22:45Z dhoover $

package com.threerings.stats;

import java.util.logging.Logger;

/**
 * A placeholder class that contains a reference to the log object used by this project.
 */
public class Log
{
    /** We dispatch our log messages through this logger. */
    public static Logger log = Logger.getLogger("com.threerings.stats");
}

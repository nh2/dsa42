The code in here is out of date and out of sync, but will not be updated
until needed, as we're focusing on flash development.

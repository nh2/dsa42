//
// $Id: ModPlayer.java 306 2007-10-17 23:34:32Z dhoover $
//
// Nenya library - tools for developing networked games
// Copyright (C) 2002-2007 Three Rings Design, Inc., All Rights Reserved
// http://www.threerings.net/code/nenya/
//
// This library is free software; you can redistribute it and/or modify it
// under the terms of the GNU Lesser General Public License as published
// by the Free Software Foundation; either version 2.1 of the License, or
// (at your option) any later version.
//
// This library is distributed in the hope that it will be useful,
// but WITHOUT ANY WARRANTY; without even the implied warranty of
// MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the GNU
// Lesser General Public License for more details.
//
// You should have received a copy of the GNU Lesser General Public
// License along with this library; if not, write to the Free Software
// Foundation, Inc., 59 Temple Place, Suite 330, Boston, MA 02111-1307 USA

package com.threerings.media.sound;

import java.io.DataInputStream;
import java.io.InputStream;

import micromod.MicroMod;
import micromod.Module;
import micromod.ModuleLoader;
import micromod.output.JavaSoundOutputDevice;
import micromod.output.OutputDeviceException;
import micromod.output.converters.SS16LEAudioFormatConverter;
import micromod.resamplers.LinearResampler;

/**
 * A player that plays .mod format music.
 */
public class ModPlayer extends MusicPlayer
{
    @Override // documentation inherited
    public void init ()
        throws Exception
    {
        _device = new NaryaSoundDevice();
        _device.start();
    }

    @Override // documentation inherited
    public void shutdown ()
    {
        _device.stop();
    }

    @Override // documentation inherited
    public void start (InputStream stream)
        throws Exception
    {
        Module module = ModuleLoader.read(new DataInputStream(stream));

        final MicroMod mod = new MicroMod(module, _device, new LinearResampler());

        _player = new Thread("narya mod player") {
            public void run () {

                while (mod.getSequenceLoopCount() == 0) {

                    mod.doRealTimePlayback();
                    try {
                        Thread.sleep(20);
                    } catch (InterruptedException ie) {
                        // WFCares
                    }

                    if (_player != Thread.currentThread()) {
                        // we were stopped!
                        return;
                    }
                }
                _device.drain();
                _musicListener.musicStopped();
            }
        };

        _player.setDaemon(true);
        _player.start();
    }

    @Override // documentation inherited
    public void stop ()
    {
        _player = null;
    }

    @Override // documentation inherited
    public void setVolume (float vol)
    {
        _device.setVolume(vol);
    }

    /**
     * A class that allows us to access the dataline so we can adjust
     * the volume.
     */
    protected static class NaryaSoundDevice extends JavaSoundOutputDevice
    {
        public NaryaSoundDevice ()
            throws OutputDeviceException
        {
            super(new SS16LEAudioFormatConverter(), 44100, 1000);
        }

        @Override // documentation inherited
        public void setVolume (float vol)
        {
            SoundManager.adjustVolume(sourceDataLine, vol);
        }

        @Override // documentation inherited
        public void drain ()
        {
            sourceDataLine.drain();
        }
    }

    /** The thread that does the work. */
    protected Thread _player;

    /** The sound output device. */
    protected NaryaSoundDevice _device;
}

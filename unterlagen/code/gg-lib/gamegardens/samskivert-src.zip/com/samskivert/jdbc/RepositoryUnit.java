//
// $Id$
//
// samskivert library - useful routines for java programs
// Copyright (C) 2001-2007 Michael Bayne
// 
// This library is free software; you can redistribute it and/or modify it
// under the terms of the GNU Lesser General Public License as published
// by the Free Software Foundation; either version 2.1 of the License, or
// (at your option) any later version.
//
// This library is distributed in the hope that it will be useful,
// but WITHOUT ANY WARRANTY; without even the implied warranty of
// MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the GNU
// Lesser General Public License for more details.
//
// You should have received a copy of the GNU Lesser General Public
// License along with this library; if not, write to the Free Software
// Foundation, Inc., 59 Temple Place, Suite 330, Boston, MA 02111-1307 USA

package com.samskivert.jdbc;

import java.util.logging.Level;

import com.samskivert.Log;
import com.samskivert.io.PersistenceException;
import com.samskivert.util.Invoker;

/**
 * Extends the {@link com.samskivert.util.Invoker.Unit} and specializes it for doing database
 * repository manipulation.
 */
public abstract class RepositoryUnit extends Invoker.Unit
{
    /** The default constructor. */
    public RepositoryUnit ()
    {
    }

    /**
     * Create a RepositoryUnit which will report the supplied name in {@link #toString}.
     */
    public RepositoryUnit (String name)
    {
        super(name);
    }

    // from abstract Invoker.Unit
    public boolean invoke ()
    {
        try {
            invokePersist();
        } catch (Exception pe) {
            _error = pe;
        }
        return true;
    }

    @Override // from Invoker.Unit
    public void handleResult ()
    {
        if (_error != null) {
            handleFailure(_error);
        } else {
            handleSuccess();
        }
    }

    /**
     * Called to perform our persistent actions.
     */
    public abstract void invokePersist ()
        throws Exception;

    /**
     * Called if our persistent actions have succeeded, back on the non-invoker thread.
     */
    public abstract void handleSuccess ();

    /**
     * Called if our persistent actions failed, back on the non-invoker thread.  Note that this may
     * be either an {@link Exception} thrown by {@link #invokePersist} or a {@link
     * RuntimeException} thrown by same. The default implementation logs an error message and a
     * stack trace.
     */
    public void handleFailure (Exception pe)
    {
        Log.log.log(Level.WARNING, getFailureMessage(), pe);
    }

    /**
     * Returns the error message to be logged if {@link #invokePersist} throws an exception.
     */
    protected String getFailureMessage ()
    {
        return this + " failed.";
    }

    protected Exception _error;
}
